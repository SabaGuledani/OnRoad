package com.example.onroad.classes

open class User {
    var useruid:String = ""
    var name:String = "name"
    var surname:String = ""
    var number:String = ""
    var number2:String = ""
    var email:String = ""
    var languages = arrayListOf<String>()
    var country:String = ""
}